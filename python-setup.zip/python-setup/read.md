I want to setup python environment where I can:
* run scripts and editing in visual studio code
    * build a number guessing name. The computer picks a random number, and the player has a limited number of attempts to guess it. The game provides hints like "Too high!" or "Too low!
* run jupyter notebooks in visual studio code
    * run basic commands in the notebook
* I am running ubunto on windows machine
* I want detailed instructions, not link to web sites